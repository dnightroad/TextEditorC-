﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Awesome_Editor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //now fajl
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
        //pole za vuvejdane na bogat tekst
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //otvarqne na fajla
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Title = " Moqt otvoren prozorec";
            if (openfile.ShowDialog()==DialogResult.OK)
            {
                richTextBox1.Clear();
                using (StreamReader sr = new StreamReader(openfile.FileName))
                {
                    richTextBox1.Text = sr.ReadToEnd();
                    sr.Close();
                }
            }
          
        }
        //zapazvane na fajla
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog zapazi = new SaveFileDialog();
            zapazi.Title = "zapazi fajla kato";
            if(zapazi.ShowDialog()==DialogResult.OK)
            {
                StreamWriter txtoutput = new StreamWriter(zapazi.FileName);
                txtoutput.Write(richTextBox1.Text);
                txtoutput.Close();
            }
           
        }

        private void noHelpHerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //udebelqvane na shrifta
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.BackColor !=SystemColors.ControlDark)
            {
                this.BackColor = SystemColors.ControlDark;
            }
            if (!(this.Font.Bold))
            {
                this.Font = new Font(this.Font, FontStyle.Bold);
            }
        }
        //buton za izhodod ot programata
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //naklonen shrift
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (!(this.Font.Italic))
            {
                this.Font = new Font(this.Font, FontStyle.Italic);
            }
        }
        //podchertan
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (!(this.Font.Underline))
            {
                this.Font = new Font(this.Font, FontStyle.Underline);
            }
        }
    }
}
